## Server setup
Download Repo, navigate to it and run the commands: "npm install", then "node server.js"
Now the backend is running!!

## Database
Right now we are just using a free mongodb provider for development. So make a config.json file and hit me up for credentials to put in there.
